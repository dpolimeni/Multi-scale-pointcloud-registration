#!bin/bash

black --line-length 120 .