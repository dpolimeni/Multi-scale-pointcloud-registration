#!/bin/bash

export PYTHONPATH=$(pwd):$PYTHONPATH
python3 main.py